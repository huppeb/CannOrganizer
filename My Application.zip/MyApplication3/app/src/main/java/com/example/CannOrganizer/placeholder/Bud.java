package com.example.CannOrganizer.placeholder;

import java.util.ArrayList;
import java.util.List;

public class Bud {
   public String ID;
   public String Type;
   public  String Grower;
   public String Strain;
   public String Cultivar;
   public String THC;
   public String Price;
   public String BuyLocation;



    public Bud( String type,String grower, String strain, String cultivar, String thc, String price, String buyLocation){
      Type = type;
      Grower = grower;
      Strain = strain;
      Cultivar = cultivar;
      THC = thc;
      Price = price;
      BuyLocation = buyLocation;



    }
 //   public String GetID(){
       // return ID;
 //   }
    public String getGrower(){
        return "Grower: " + Grower;
    }
    public String getStrain() {return "Strain: " + Strain; }


}
