package com.example.CannOrganizer;

import android.os.Bundle;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;

import com.example.myapplication.R;


public class MainPage extends Fragment {


    public MainPage() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_main_page, container, false);

        ImageButton budList = view.findViewById(R.id.Bud_List);
        ImageButton concentrateList = view.findViewById(R.id.Concentrates);
        ImageButton edibleList = view.findViewById(R.id.Edibles);
        ImageButton VapeList = view.findViewById(R.id.Vapes);

        budList.setOnClickListener(view1 -> Navigation.findNavController(view1).navigate(R.id.GoToBuds));
        concentrateList.setOnClickListener(view1 -> Navigation.findNavController(view1).navigate(R.id.action_mainPage_to_concentrateList));
        edibleList.setOnClickListener(view1 -> Navigation.findNavController(view1).navigate(R.id.action_mainPage_to_edibleList));
        VapeList.setOnClickListener(view1 -> Navigation.findNavController(view1).navigate(R.id.action_mainPage_to_vapeList));

// This callback will only be called when MyFragment is at least Started.

        return view;
    }

}