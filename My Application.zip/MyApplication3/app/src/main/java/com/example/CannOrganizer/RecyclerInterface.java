package com.example.CannOrganizer;

public interface RecyclerInterface {
    void onItemClick(int position);
    void DeleteClick(int position);
}
