package com.example.CannOrganizer;

import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.example.myapplication.R;
import com.example.CannOrganizer.placeholder.Bud;

import java.util.List;


public class MyItemRecyclerViewAdapter extends RecyclerView.Adapter<MyItemRecyclerViewAdapter.ViewHolder> {

    private final List<Bud> mValues;
    RecyclerInterface RecyclerListener;


    public MyItemRecyclerViewAdapter(List<Bud> list, RecyclerInterface listener) {

        mValues = list;
        RecyclerListener = listener;

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        //return new ViewHolder(FragmentItemBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem= layoutInflater.inflate(R.layout.fragment_item, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;


    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {

        holder.mItem = mValues.get(position);
        holder.mIdView.setText(String.valueOf(position));
        holder.mGrowerView.setText(mValues.get(position).getGrower());
        holder.mStrainView.setText(mValues.get(position).getStrain());
        holder.mDelete.setOnClickListener(view1 ->{
            RecyclerListener.DeleteClick(position);
            notifyItemRemoved(position);
        });

        holder.itemView.setOnClickListener(view -> {
           RecyclerListener.onItemClick(position);
        });



    }

    @Override
    public long getItemId(int position) {
        return super.getItemId(position);
    }

    @Override
    public int getItemCount() {
        return mValues.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public final TextView mIdView;
        public final TextView mGrowerView;
        public final TextView mStrainView;
        public final Button mDelete;
        public Bud mItem;

        public ViewHolder(View view) {
            super(view);
            mIdView = view.findViewById(R.id.item_number);
            mGrowerView = view.findViewById(R.id.Grower);
            mStrainView = view.findViewById(R.id.Strain);
            mDelete = view.findViewById(R.id.delete);
        }

        @Override
        public String toString() {
            return super.toString() + " '" + mGrowerView.getText() + "' '" + mStrainView.getText() + "'";
        }

    }
}