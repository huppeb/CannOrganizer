package com.example.CannOrganizer;

import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.example.CannOrganizer.placeholder.Bud;
import com.example.myapplication.R;

import java.util.ArrayList;


public class EdibleList extends Fragment implements RecyclerInterface{
    CannaDatabase db;
    ArrayList<Bud> edibleList = new ArrayList<>();
    EditText grower,strain,cultivar,thc,price,location;
String Type;


    public EdibleList() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        db = CannaDatabase.getInstance();
        View view = inflater.inflate(R.layout.fragment_concentrate_list, container, false);
        RadioGroup TypeSelect = view.findViewById(R.id.Product_Type);
        RadioButton valueSetter = view.findViewById(TypeSelect.getCheckedRadioButtonId());

        edibleList.addAll(getItems(db.GetBuds()));

        Button AddNew = view.findViewById(R.id.AddItem);
        grower = view.findViewById(R.id.Grower_Name);
        strain = view.findViewById(R.id.Strain_Name);
        cultivar = view.findViewById(R.id.Cultivar_Type);
        thc = view.findViewById(R.id.THC_Level);

        price = view.findViewById(R.id.Item_Price);
        location = view.findViewById(R.id.Buy_Loc);


        RecyclerView recyclerView = view.findViewById(R.id.List_Buds);
        MyItemRecyclerViewAdapter adapter = new  MyItemRecyclerViewAdapter(edibleList,this);
        recyclerView.setLayoutManager(new LinearLayoutManager(view.getContext()));
        recyclerView.setAdapter(adapter);
        db = CannaDatabase.getInstance();

        TypeSelect.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                switch(i){
                    case R.id.Type_Bud:
                        Type = "Bud";
                        break;
                    case R.id.Type_Concentrate:
                        Type = "Concentrate";
                        break;
                    case R.id.Type_Edible:
                        Type = "Edible";
                        break;
                    case R.id.Type_Vape:
                        Type = "Vape";
                        break;
                }
            }
        });

        AddNew.setOnClickListener(View ->{
            {
                String value, value1,value2,value3,value4,value5,value6;

                value1 = grower.getText().toString();
                value2 = strain.getText().toString();
                value3 = cultivar.getText().toString();
                value4 = thc.getText().toString();
                value5 = price.getText().toString();
                value6 = location.getText().toString();

                db.addItem(new Bud(Type,value1,value2,value3,value4,value5,value6));
                edibleList.clear();
                edibleList.addAll(getItems(db.GetBuds()));
                adapter.notifyItemInserted(edibleList.size());
            }
        });



        return view;
    }

    @Override
    public void onItemClick(int position) {
        Bud clicked = edibleList.get(position);
        TextView Grower,Strain,Cultivar,Thc,Price,Location;

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getContext());
        // Set title
        alertDialogBuilder.setTitle("Item Info");
        alertDialogBuilder.setCancelable(true);


        //setting the view of the dialog box as the custom design i created.
        alertDialogBuilder.setView(R.layout.item_info);
        final AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();

        Grower = alertDialog.findViewById(R.id.GrowerSnack);
        String info1 = "Grower Name: " + clicked.Grower;
        Grower.setText(info1);

        Strain = alertDialog.findViewById(R.id.SnackStrain);
        String info2 = "Strain Name: " + clicked.Strain;
        Strain.setText(info2);

        Cultivar = alertDialog.findViewById(R.id.CultivarSnack);
        String info3 = "Cultivar: " + clicked.Cultivar;
        Cultivar.setText(info3);

        Thc = alertDialog.findViewById(R.id.ThcSnack);
        String info4 = "THC Percent: " + clicked.THC + "%";
        Thc.setText(info4);

        Price = alertDialog.findViewById(R.id.PriceSnack);
        String info5 = "Price: " + clicked.Price;
        Price.setText(info5);

        Location = alertDialog.findViewById(R.id.Location);
        String info6 = "It was bought at: " + clicked.BuyLocation;
        Location.setText(info6);

        Button cancelButton = alertDialog.findViewById(R.id.close);

        cancelButton.setOnClickListener(view ->{
            alertDialog.cancel();
        });
    }

    @Override
    public void DeleteClick(int position) {
        db.deleteItem(edibleList.get(position));
        edibleList.remove(position);

    }
    private ArrayList<Bud> getItems(ArrayList<Bud> values){
        ArrayList<Bud> temp = new ArrayList<>();
        for (Bud item: values){
            if(item.Type.equals("Edible")){
                temp.add(item);
            }

        }
        return temp;
    }
}