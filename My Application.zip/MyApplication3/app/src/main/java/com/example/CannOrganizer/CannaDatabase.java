package com.example.CannOrganizer;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.CannOrganizer.placeholder.Bud;

import java.util.ArrayList;

public class CannaDatabase extends SQLiteOpenHelper {
    private static CannaDatabase DataInstance;
    private static final String DATABASE_NAME = "DB";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "CannaData";
    private static final String ITEM_ID = "ID";
    private static final String ITEM_TYPE = "Type";
    private static final String GROWER_NAME = "Grower";
    private static final String STRAIN_NAME = "Strain";
    private static final String CULTIVAR_TYPE = "Cultivar";
    private static final String THC_LEVEL = "THC";
    private static final String ITEM_PRICE = "Price";
    private static final String BUY_LOC = "buyLocation";
    // ...

    public static synchronized CannaDatabase getInstance() {
        // Use the application context, which will ensure that you
        // don't accidentally leak an Activity's context.
        // See this article for more information: http://bit.ly/6LRzfx
        if (DataInstance == null) {
            throw new IllegalStateException();
        }
        return DataInstance;
    }
    public static void instantiateInstance(Context context){
        DataInstance = new CannaDatabase(context.getApplicationContext());
    }

    /**
     * Constructor should be private to prevent direct instantiation.
     * Make a call to the static method "getInstance()" instead.
     */
    private CannaDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME +
                "(" +
                ITEM_ID + " INTEGER PRIMARY KEY, " +
                ITEM_TYPE + " VARCHAR(255)," +
                GROWER_NAME + " VARCHAR(255)," +
                STRAIN_NAME + " VARCHAR(255)," +
                CULTIVAR_TYPE + " VARCHAR(255), " +
                THC_LEVEL + " VARCHAR(255), " +
                ITEM_PRICE + " VARCHAR(255), " +
                BUY_LOC + " VARCHAR(255) " +
                ")";

        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

        String deleteTable = "DROP TABLE IF EXISTS " + TABLE_NAME;
        if(i != i1){
            db.execSQL(deleteTable);
            onCreate(db);
        }
    }

    public void addItem(Bud nBud){

        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues values = new ContentValues();
            values.put(ITEM_TYPE,nBud.Type);
            values.put(GROWER_NAME, nBud.Grower);
            values.put(STRAIN_NAME, nBud.Strain);
            values.put(CULTIVAR_TYPE,nBud.Cultivar);
            values.put(THC_LEVEL, nBud.THC);
            values.put(ITEM_PRICE,nBud.Price);
            values.put(BUY_LOC,nBud.BuyLocation);
            db.insertOrThrow(TABLE_NAME, null, values);
            db.setTransactionSuccessful();


        }

        catch (Exception e){
            e.printStackTrace();
        }

        finally{
            db.endTransaction();
        }
    }

    // deleting an item from the database
    public void deleteItem(Bud nBud){
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            db.delete(TABLE_NAME, ITEM_ID + " = ?",new String[]{nBud.ID});
            db.setTransactionSuccessful();
            }
        catch (Exception e){
            e.printStackTrace();
        }
        finally{
            db.endTransaction();
        }
    }

    //geting the items from the database
    public ArrayList<Bud> GetBuds(){
        ArrayList<Bud> tempList = new ArrayList<Bud>();
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try{


            String statement = ("select * from " + TABLE_NAME);


           // db.rawQuery(statement, new String[] {});
            Cursor data = db.rawQuery(statement,null);
            int IdIndex = data.getColumnIndex(ITEM_ID);
            int TypeIndex = data.getColumnIndex(ITEM_TYPE);
            int GrowerIndex = data.getColumnIndex(GROWER_NAME);
            int StrainIndex = data.getColumnIndex(STRAIN_NAME);
            int CultivarIndex = data.getColumnIndex(CULTIVAR_TYPE);
            int THCIndex = data.getColumnIndex(THC_LEVEL);
            int PriceIndex = data.getColumnIndex(ITEM_PRICE);
            int BuyIndex = data.getColumnIndex(BUY_LOC);

            data.moveToFirst();
            while(data.moveToNext()){
                String id = data.getString(IdIndex);
                String Type = data.getString(TypeIndex);
                String grower = data.getString(GrowerIndex);
                String strain = data.getString(StrainIndex);
                String cultivar = data.getString(CultivarIndex);
                String thc = data.getString(THCIndex);
                String price = data.getString(PriceIndex);
                String buyLoc = data.getString(BuyIndex);

                Bud temp =  new Bud(Type,grower,strain,cultivar,thc,price,buyLoc);
                temp.ID = id;

                tempList.add(temp);
                data.moveToNext();
            }
            db.setTransactionSuccessful();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        finally {
            db.endTransaction();
        }
        return tempList;
    }


}
